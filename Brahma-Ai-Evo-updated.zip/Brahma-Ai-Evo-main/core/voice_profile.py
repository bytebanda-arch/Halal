"""
core/voice_profile.py
Shared voice settings for every Gemini Live session in Brahma (desktop).

* Default voice is a female voice ("Kore"). Change it with the BRAHMA_VOICE_NAME environment
  variable or the "live_voice_name" key in app_settings.json.
* All listed voices speak and understand Hindi (hi-IN).
"""

from __future__ import annotations

import os

# Gemini prebuilt voices that sound female.
FEMALE_VOICES = (
    "Kore", "Aoede", "Leda", "Zephyr", "Sulafat", "Autonoe", "Callirrhoe", "Despina",
)
DEFAULT_VOICE = "Kore"

HINDI_VOICE_INSTRUCTION = (
    "LANGUAGE & VOICE: You are a female assistant. The user mainly speaks Hindi, Hinglish and sometimes English. "
    "Understand Hindi carefully, including casual and mixed Hindi-English speech. "
    "RESPOND IN THE SAME LANGUAGE THE USER SPEAKS - reply in natural spoken Hindi when the user speaks Hindi or Hinglish "
    "(English technical words are fine). "
    "Use feminine grammar for yourself (for example 'main kar rahi hoon' / 'मैं कर रही हूँ'). "
    "The wake words 'Brahma', 'Brahma Evo' and 'ब्रह्मा' all mean the user is calling you."
)


def get_live_voice_name() -> str:
    """Return the configured Gemini Live voice (female by default)."""
    name = os.environ.get("BRAHMA_VOICE_NAME", "").strip()
    if not name:
        try:
            from memory import config_manager
            name = str(config_manager.get_setting("live_voice_name", "") or "").strip()
        except Exception:
            name = ""
    return name or DEFAULT_VOICE

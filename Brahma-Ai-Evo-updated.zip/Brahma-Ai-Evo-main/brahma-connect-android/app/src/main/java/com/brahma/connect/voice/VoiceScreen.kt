package com.brahma.connect.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

private fun hasMic(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED

@Composable
fun VoiceScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { VoicePrefs(context) }

    val mode by VoiceStateStore.mode.collectAsState()
    val status by VoiceStateStore.status.collectAsState()
    val error by VoiceStateStore.error.collectAsState()
    val lines by VoiceStateStore.lines.collectAsState()
    val wakeActive by VoiceStateStore.wakeActive.collectAsState()

    var apiKey by remember { mutableStateOf(prefs.apiKey) }
    var voice by remember { mutableStateOf(prefs.voice) }
    var wakeWords by remember { mutableStateOf(prefs.wakeWords) }
    var model by remember { mutableStateOf(prefs.model) }
    var pendingAction by remember { mutableStateOf<String?>(null) }
    var saved by remember { mutableStateOf(false) }

    fun saveAll() {
        prefs.apiKey = apiKey
        prefs.voice = voice
        prefs.wakeWords = wakeWords
        prefs.model = model
    }

    fun startService(action: String) {
        saveAll()
        val intent = Intent(context, BrahmaVoiceService::class.java).setAction(action)
        ContextCompat.startForegroundService(context, intent)
    }

    fun stopService(action: String) {
        val intent = Intent(context, BrahmaVoiceService::class.java).setAction(action)
        context.startService(intent)
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { result ->
        val micOk = result[Manifest.permission.RECORD_AUDIO] == true || hasMic(context)
        val action = pendingAction
        pendingAction = null
        if (!micOk) {
            VoiceStateStore.setError("माइक की permission के बिना voice नहीं चलेगा")
        } else if (action != null) {
            startService(action)
        }
    }

    fun requestAndStart(action: String) {
        if (apiKey.isBlank()) {
            VoiceStateStore.setError("पहले नीचे Gemini API key डालकर सेव कीजिए")
            return
        }
        val needed = mutableListOf<String>()
        if (!hasMic(context)) needed.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needed.isEmpty()) {
            startService(action)
        } else {
            pendingAction = action
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    val inConversation = mode == VoiceMode.LIVE || mode == VoiceMode.CONNECTING

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.7f))
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← वापस", color = Color.White) }
            Spacer(Modifier.padding(horizontal = 4.dp))
            Text(
                "BRAHMA VOICE",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                color = Color.White,
            )
        }
        Spacer(Modifier.height(12.dp))

        // ---- status
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color.Black.copy(alpha = 0.55f),
                contentColor = Color.White,
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
        ) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    when (mode) {
                        VoiceMode.OFF -> "● बंद"
                        VoiceMode.WAKE_LISTENING -> "● Wake word सुन रहा है"
                        VoiceMode.CONNECTING -> "● जुड़ रहा है…"
                        VoiceMode.LIVE -> "● Live बातचीत चालू"
                    },
                    fontWeight = FontWeight.Bold,
                )
                Spacer(Modifier.height(4.dp))
                Text(status, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (!error.isNullOrBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(error ?: "", color = MaterialTheme.colorScheme.error)
                }
            }
        }
        Spacer(Modifier.height(16.dp))

        // ---- live talk
        if (inConversation) {
            Button(
                onClick = { stopService(BrahmaVoiceService.ACTION_STOP_LIVE) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("बातचीत बंद करें") }
        } else {
            Button(
                onClick = { requestAndStart(BrahmaVoiceService.ACTION_START_LIVE) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Live Talk शुरू करें") }
        }
        Spacer(Modifier.height(12.dp))

        // ---- wake word
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Wake word", color = Color.White, fontWeight = FontWeight.Bold)
                Text(
                    "\"ब्रह्मा\" बोलते ही Live Talk शुरू हो जाएगा",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Switch(
                checked = wakeActive,
                onCheckedChange = { on ->
                    if (on) requestAndStart(BrahmaVoiceService.ACTION_START_WAKE)
                    else stopService(BrahmaVoiceService.ACTION_STOP_ALL)
                },
            )
        }
        Spacer(Modifier.height(16.dp))

        // ---- conversation
        if (lines.isNotEmpty()) {
            Text("बातचीत", color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            lines.takeLast(12).forEach { line ->
                val who = if (line.role == "user") "आप" else "Brahma"
                Text(
                    "$who: ${line.text}",
                    color = if (line.role == "user") Color.White else MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(vertical = 2.dp),
                )
            }
            Spacer(Modifier.height(16.dp))
        }

        // ---- settings
        Text("सेटिंग्स", color = Color.White, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = apiKey,
            onValueChange = {
                apiKey = it
                saved = false
            },
            label = { Text("Gemini API key") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            "Key सिर्फ़ इसी फ़ोन में encrypted रहती है और सिर्फ़ Google को भेजी जाती है।",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 4.dp),
        )
        Spacer(Modifier.height(12.dp))

        Text("आवाज़ (female)", color = Color.White)
        VoiceDefaults.FEMALE_VOICES.forEach { name ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(
                    selected = voice == name,
                    onClick = {
                        voice = name
                        saved = false
                    },
                )
                Text(name, color = Color.White)
            }
        }
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = wakeWords,
            onValueChange = {
                wakeWords = it
                saved = false
            },
            label = { Text("Wake words (comma से अलग)") },
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = model,
            onValueChange = {
                model = it
                saved = false
            },
            label = { Text("Gemini Live model (advanced)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(12.dp))

        OutlinedButton(
            onClick = {
                saveAll()
                saved = true
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (saved) "सेव हो गया ✓" else "सेटिंग्स सेव करें", color = Color.White) }

        Spacer(Modifier.height(24.dp))
    }
}

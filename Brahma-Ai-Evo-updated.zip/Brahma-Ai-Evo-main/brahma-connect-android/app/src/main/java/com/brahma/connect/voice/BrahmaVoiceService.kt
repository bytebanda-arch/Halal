package com.brahma.connect.voice

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.brahma.connect.R

/**
 * Foreground (microphone) service for Brahma voice.
 *
 *  ACTION_START_WAKE -> listen for the wake word ("ब्रह्मा"); on hearing it, open a live conversation
 *  ACTION_START_LIVE -> open a live conversation right now (button press)
 *  ACTION_STOP_LIVE  -> end the conversation (goes back to wake word listening if it was on)
 *  ACTION_STOP_ALL   -> stop everything
 */
class BrahmaVoiceService : Service(), GeminiLiveClient.Listener {

    private val main = Handler(Looper.getMainLooper())
    private lateinit var prefs: VoicePrefs
    private lateinit var audio: AudioManager

    private var detector: WakeWordDetector? = null
    private var live: GeminiLiveClient? = null
    private var liveStarting = false
    private var wakeEnabled = false
    private var foregroundStarted = false

    private var routed = false
    private var savedAudioMode = AudioManager.MODE_NORMAL
    private var savedSpeaker = false

    override fun onCreate() {
        super.onCreate()
        prefs = VoicePrefs(this)
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_WAKE -> {
                if (!enterForeground()) return START_NOT_STICKY
                wakeEnabled = true
                VoiceStateStore.setWakeActive(true)
                VoiceStateStore.setError(null)
                if (live == null && !liveStarting) startWake()
            }
            ACTION_START_LIVE -> {
                if (!enterForeground()) return START_NOT_STICKY
                startLive()
            }
            ACTION_STOP_LIVE -> {
                val client = live
                if (client != null) {
                    client.stop("बातचीत बंद की") // onEnded() follows
                } else {
                    liveStarting = false
                    afterLive()
                }
            }
            ACTION_STOP_ALL -> shutdown()
        }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ wake word

    private fun startWake() {
        if (!hasMicPermission()) {
            VoiceStateStore.setError("माइक की permission दीजिए")
            shutdown()
            return
        }
        val d = detector ?: WakeWordDetector(
            context = applicationContext,
            wakeWords = { parseWords(prefs.wakeWords) },
            onWake = { onWakeWord() },
            onFatal = { message ->
                VoiceStateStore.setError(message)
                shutdown()
            },
        ).also { detector = it }
        VoiceStateStore.setMode(VoiceMode.WAKE_LISTENING, "सुन रहा है - \"ब्रह्मा\" बोलकर बुलाइए")
        updateNotification("सुन रहा है - \"ब्रह्मा\" बोलकर बुलाइए")
        d.start()
    }

    private fun onWakeWord() {
        beep()
        startLive()
    }

    // ------------------------------------------------------------------ live talk

    private fun startLive() {
        if (live != null || liveStarting) return
        val key = prefs.apiKey
        if (key.isBlank()) {
            VoiceStateStore.setError("पहले Gemini API key सेव कीजिए")
            afterLive()
            return
        }
        if (!hasMicPermission()) {
            VoiceStateStore.setError("माइक की permission दीजिए")
            afterLive()
            return
        }
        liveStarting = true
        detector?.stop() // the microphone must be free for the live session
        VoiceStateStore.setError(null)
        VoiceStateStore.setMode(VoiceMode.CONNECTING, "Brahma से जुड़ रहा है…")
        updateNotification("जुड़ रहा है…")
        main.postDelayed({
            if (!liveStarting) return@postDelayed
            liveStarting = false
            if (!foregroundStarted) return@postDelayed
            beginAudioRoute()
            val client = GeminiLiveClient(this)
            live = client
            client.start(key, modelCandidates(), prefs.voice, VoiceDefaults.SYSTEM_PROMPT)
        }, 350)
    }

    override fun onReady() {
        if (live == null) return
        VoiceStateStore.setMode(VoiceMode.LIVE, "बोलिए, मैं सुन रही हूँ")
        updateNotification("बातचीत चल रही है")
    }

    override fun onEnded(reason: String, isError: Boolean) {
        live = null
        liveStarting = false
        endAudioRoute()
        if (isError) VoiceStateStore.setError(reason)
        VoiceStateStore.setMode(
            if (wakeEnabled) VoiceMode.WAKE_LISTENING else VoiceMode.OFF,
            reason,
        )
        afterLive()
    }

    private fun afterLive() {
        if (wakeEnabled && foregroundStarted) {
            main.postDelayed({
                if (live == null && !liveStarting && wakeEnabled && foregroundStarted) startWake()
            }, 700)
        } else {
            shutdown()
        }
    }

    // ------------------------------------------------------------------ lifecycle

    private fun shutdown() {
        wakeEnabled = false
        liveStarting = false
        VoiceStateStore.setWakeActive(false)
        main.removeCallbacksAndMessages(null)
        detector?.stop()
        detector = null
        val client = live
        live = null
        client?.stop("बंद किया")
        endAudioRoute()
        VoiceStateStore.setMode(VoiceMode.OFF, "बंद है")
        if (foregroundStarted) {
            foregroundStarted = false
            stopForeground(STOP_FOREGROUND_REMOVE)
        }
        stopSelf()
    }

    override fun onDestroy() {
        wakeEnabled = false
        main.removeCallbacksAndMessages(null)
        detector?.stop()
        detector = null
        live?.stop("बंद किया")
        live = null
        endAudioRoute()
        VoiceStateStore.setWakeActive(false)
        VoiceStateStore.setMode(VoiceMode.OFF, "बंद है")
        super.onDestroy()
    }

    // ------------------------------------------------------------------ helpers

    private fun hasMicPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun parseWords(raw: String): List<String> =
        raw.split(',', '،', '\n', ';').map { it.trim() }.filter { it.isNotEmpty() }

    private fun modelCandidates(): List<String> {
        val all = listOf(prefs.model) + VoiceDefaults.FALLBACK_MODELS
        return all
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .map { if (it.startsWith("models/")) it else "models/$it" }
            .distinct()
    }

    @Suppress("DEPRECATION")
    private fun beginAudioRoute() {
        if (routed) return
        try {
            savedAudioMode = audio.mode
            savedSpeaker = audio.isSpeakerphoneOn
            audio.mode = AudioManager.MODE_IN_COMMUNICATION
            // Use the loudspeaker unless a wired headset is plugged in.
            audio.isSpeakerphoneOn = !audio.isWiredHeadsetOn
            routed = true
        } catch (_: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun endAudioRoute() {
        if (!routed) return
        routed = false
        try {
            audio.isSpeakerphoneOn = savedSpeaker
            audio.mode = savedAudioMode
        } catch (_: Exception) {
        }
    }

    private fun beep() {
        try {
            val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            tone.startTone(ToneGenerator.TONE_PROP_ACK, 150)
            main.postDelayed({
                try {
                    tone.release()
                } catch (_: Exception) {
                }
            }, 400)
        } catch (_: Exception) {
        }
    }

    private fun enterForeground(): Boolean {
        if (foregroundStarted) return true
        return try {
            val notification = buildNotification("तैयार")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE,
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            foregroundStarted = true
            true
        } catch (t: Throwable) {
            VoiceStateStore.setError("Voice service शुरू नहीं हो पाई: ${t.message}")
            VoiceStateStore.setMode(VoiceMode.OFF, "बंद है")
            stopSelf()
            false
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(CHANNEL_ID, "Brahma Voice", NotificationManager.IMPORTANCE_LOW)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, BrahmaVoiceService::class.java).setAction(ACTION_STOP_ALL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_brahma_launcher)
            .setContentTitle("Brahma Voice")
            .setContentText(text)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, "बंद करें", stopIntent)
            .build()
    }

    private fun updateNotification(text: String) {
        if (!foregroundStarted) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    companion object {
        const val ACTION_START_WAKE = "com.brahma.connect.voice.START_WAKE"
        const val ACTION_START_LIVE = "com.brahma.connect.voice.START_LIVE"
        const val ACTION_STOP_LIVE = "com.brahma.connect.voice.STOP_LIVE"
        const val ACTION_STOP_ALL = "com.brahma.connect.voice.STOP_ALL"
        private const val CHANNEL_ID = "brahma_voice"
        private const val NOTIFICATION_ID = 4202
    }
}

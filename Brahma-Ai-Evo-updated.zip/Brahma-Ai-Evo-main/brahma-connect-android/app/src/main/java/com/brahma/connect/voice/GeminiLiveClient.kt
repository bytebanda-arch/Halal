package com.brahma.connect.voice

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Real-time two-way voice conversation with Gemini Live (native audio).
 *
 *  - microphone: 16 kHz mono PCM16, streamed continuously
 *  - speaker:    24 kHz mono PCM16 replies in the chosen (female) voice
 *  - barge-in:   when the user interrupts, queued speech is flushed immediately
 *
 * The [Listener] callbacks are always delivered on the main thread.
 */
class GeminiLiveClient(private val listener: Listener) {

    interface Listener {
        /** Connection is ready - the user can talk now. */
        fun onReady()

        /** Session finished (for any reason). Called exactly once. */
        fun onEnded(reason: String, isError: Boolean)
    }

    private val http = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private val main = Handler(Looper.getMainLooper())

    private val running = AtomicBoolean(false)
    private val ready = AtomicBoolean(false)
    private val ended = AtomicBoolean(false)
    private val wsGeneration = AtomicInteger(0)

    @Volatile private var socket: WebSocket? = null
    @Volatile private var recorder: AudioRecord? = null
    @Volatile private var track: AudioTrack? = null
    private var micThread: Thread? = null
    private var playThread: Thread? = null
    private val playQueue = LinkedBlockingQueue<ByteArray>()
    private var echoCanceler: AcousticEchoCanceler? = null
    private var noiseSuppressor: NoiseSuppressor? = null

    @Volatile private var lastActivity = SystemClock.elapsedRealtime()
    @Volatile private var endAfterTurn = false
    private val recentUserText = StringBuilder()

    private var apiKey = ""
    private var models: List<String> = emptyList()
    private var modelIndex = 0
    private var voice = ""
    private var systemPrompt = ""

    fun start(apiKey: String, models: List<String>, voice: String, systemPrompt: String) {
        if (!running.compareAndSet(false, true)) return
        ended.set(false)
        ready.set(false)
        endAfterTurn = false
        this.apiKey = apiKey
        this.models = if (models.isEmpty()) listOf(VoiceDefaults.MODEL) else models
        this.voice = voice
        this.systemPrompt = systemPrompt
        modelIndex = 0
        lastActivity = SystemClock.elapsedRealtime()
        VoiceStateStore.clearTranscript()
        connect()
    }

    fun stop(reason: String = "बातचीत बंद की") {
        finish(reason, false)
    }

    // ---------------------------------------------------------------- connection

    private fun connect() {
        val generation = wsGeneration.incrementAndGet()
        val url = "wss://generativelanguage.googleapis.com/ws/" +
            "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"
        val request = Request.Builder().url(url).build()
        socket = http.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (generation == wsGeneration.get()) sendSetup(webSocket)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (generation == wsGeneration.get()) handleMessage(text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                if (generation == wsGeneration.get()) handleMessage(bytes.utf8())
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                try {
                    webSocket.close(1000, null)
                } catch (_: Exception) {
                }
                if (generation == wsGeneration.get()) onSocketGone(code, reason, null, null)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (generation == wsGeneration.get()) onSocketGone(-1, t.message ?: "", t, response)
            }
        })
    }

    private fun sendSetup(ws: WebSocket) {
        val model = models[modelIndex].let { if (it.startsWith("models/")) it else "models/$it" }
        val setup = JSONObject()
            .put("model", model)
            .put(
                "generationConfig",
                JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig",
                        JSONObject().put(
                            "voiceConfig",
                            JSONObject().put(
                                "prebuiltVoiceConfig",
                                JSONObject().put("voiceName", voice),
                            ),
                        ),
                    ),
            )
            .put(
                "systemInstruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", systemPrompt)),
                ),
            )
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
        ws.send(JSONObject().put("setup", setup).toString())
    }

    private fun onSocketGone(code: Int, reason: String, error: Throwable?, response: Response?) {
        if (!running.get()) return
        if (!ready.get()) {
            val status = response?.code
            val authProblem = status == 400 || status == 401 || status == 403 ||
                reason.contains("API key", ignoreCase = true)
            val offline = error is java.net.UnknownHostException ||
                error is java.net.ConnectException ||
                error is java.net.SocketTimeoutException
            // The model name may be wrong/retired: try the next candidate before giving up.
            if (!authProblem && !offline && modelIndex + 1 < models.size) {
                modelIndex++
                connect()
                return
            }
            val message = when {
                authProblem -> "Gemini API key गलत है या उसे इस model की अनुमति नहीं है"
                offline -> "इंटरनेट से कनेक्शन नहीं हो पा रहा"
                else -> "कनेक्शन fail हुआ: " + reason.ifBlank { "code $code" }
            }
            finish(message, true)
            return
        }
        finish(if (reason.isBlank()) "Session खत्म हो गया" else reason, false)
    }

    // ---------------------------------------------------------------- incoming messages

    private fun handleMessage(raw: String) {
        val root = try {
            JSONObject(raw)
        } catch (_: Exception) {
            return
        }
        if (root.has("setupComplete")) {
            onSetupComplete()
            return
        }
        if (root.has("goAway")) {
            finish("Server ने session रोक दिया", false)
            return
        }
        val content = root.optJSONObject("serverContent") ?: return
        lastActivity = SystemClock.elapsedRealtime()

        if (content.optBoolean("interrupted", false)) flushPlayback()

        val parts = content.optJSONObject("modelTurn")?.optJSONArray("parts")
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val inline = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                val mime = inline.optString("mimeType", "")
                if (!mime.startsWith("audio/")) continue
                val data = inline.optString("data", "")
                if (data.isNotEmpty()) {
                    playQueue.offer(Base64.decode(data, Base64.DEFAULT))
                }
            }
        }

        val heard = content.optJSONObject("inputTranscription")?.optString("text", "") ?: ""
        if (heard.isNotEmpty()) {
            VoiceStateStore.appendTranscript("user", heard)
            checkEndPhrase(heard)
        }
        val said = content.optJSONObject("outputTranscription")?.optString("text", "") ?: ""
        if (said.isNotEmpty()) {
            VoiceStateStore.appendTranscript("model", said)
        }

        if (content.optBoolean("turnComplete", false)) {
            VoiceStateStore.closeTurn()
            if (endAfterTurn) {
                // Let the spoken goodbye finish playing, then close.
                main.postDelayed({ finish("बातचीत खत्म", false) }, 2500)
            }
        }
    }

    private fun checkEndPhrase(chunk: String) {
        recentUserText.append(chunk.lowercase())
        if (recentUserText.length > 80) {
            recentUserText.delete(0, recentUserText.length - 80)
        }
        val text = recentUserText.toString()
        if (END_PHRASES.any { text.contains(it) }) {
            recentUserText.setLength(0)
            if (!endAfterTurn) {
                endAfterTurn = true
                // Safety net in case the model never answers.
                main.postDelayed({ finish("बातचीत खत्म", false) }, 15000)
            }
        }
    }

    private fun onSetupComplete() {
        if (!ready.compareAndSet(false, true)) return
        lastActivity = SystemClock.elapsedRealtime()
        try {
            startPlayback()
            startMic()
        } catch (se: SecurityException) {
            finish("माइक की permission नहीं मिली", true)
            return
        } catch (e: Exception) {
            finish("Audio शुरू नहीं हो पाया: ${e.message}", true)
            return
        }
        main.post { if (!ended.get()) listener.onReady() }
    }

    // ---------------------------------------------------------------- audio out

    private fun startPlayback() {
        val minBuf = AudioTrack.getMinBufferSize(
            OUT_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
        )
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build(),
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(OUT_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build(),
            )
            .setBufferSizeInBytes(maxOf(minBuf, OUT_RATE))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        t.play()
        track = t
        playThread = Thread({ playLoop(t) }, "brahma-live-play").also {
            it.isDaemon = true
            it.start()
        }
    }

    private fun playLoop(t: AudioTrack) {
        try {
            while (running.get() && !ended.get()) {
                val chunk = playQueue.poll(200, TimeUnit.MILLISECONDS) ?: continue
                if (chunk.isEmpty()) continue
                lastActivity = SystemClock.elapsedRealtime()
                t.write(chunk, 0, chunk.size)
            }
        } catch (_: InterruptedException) {
        } catch (_: Exception) {
        }
    }

    /** The user started talking over the assistant: drop everything that is still queued. */
    private fun flushPlayback() {
        playQueue.clear()
        val t = track ?: return
        try {
            t.pause()
            t.flush()
            t.play()
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- audio in

    @SuppressLint("MissingPermission")
    private fun startMic() {
        val minBuf = AudioRecord.getMinBufferSize(
            IN_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
        )
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            IN_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBuf, 6400),
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            throw IllegalStateException("माइक शुरू नहीं हो पाया")
        }
        try {
            if (AcousticEchoCanceler.isAvailable()) {
                echoCanceler = AcousticEchoCanceler.create(rec.audioSessionId)?.also { fx -> fx.setEnabled(true) }
            }
            if (NoiseSuppressor.isAvailable()) {
                noiseSuppressor = NoiseSuppressor.create(rec.audioSessionId)?.also { fx -> fx.setEnabled(true) }
            }
        } catch (_: Exception) {
        }
        rec.startRecording()
        recorder = rec
        micThread = Thread({ micLoop(rec) }, "brahma-live-mic").also {
            it.isDaemon = true
            it.start()
        }
    }

    private fun micLoop(rec: AudioRecord) {
        val buffer = ByteArray(CHUNK_BYTES)
        try {
            while (running.get() && !ended.get()) {
                val n = rec.read(buffer, 0, buffer.size)
                if (n < 0) break
                if (n == 0) continue
                val ws = socket ?: break
                val b64 = Base64.encodeToString(buffer, 0, n, Base64.NO_WRAP)
                val msg = "{\"realtimeInput\":{\"audio\":{\"data\":\"" + b64 +
                    "\",\"mimeType\":\"audio/pcm;rate=16000\"}}}"
                if (!ws.send(msg)) break
                if (SystemClock.elapsedRealtime() - lastActivity > IDLE_TIMEOUT_MS) {
                    finish("काफ़ी देर से कुछ नहीं बोला गया, बातचीत बंद", false)
                    break
                }
            }
        } catch (_: Exception) {
        }
        if (running.get() && !ended.get()) {
            finish("माइक बंद हो गया", false)
        }
    }

    // ---------------------------------------------------------------- shutdown

    private fun finish(reason: String, isError: Boolean) {
        if (!ended.compareAndSet(false, true)) return
        running.set(false)
        wsGeneration.incrementAndGet() // ignore any late socket callbacks
        try {
            socket?.close(1000, "bye")
        } catch (_: Exception) {
        }
        socket = null
        releaseAudio()
        main.post { listener.onEnded(reason, isError) }
    }

    private fun releaseAudio() {
        playQueue.clear()
        val rec = recorder
        recorder = null
        try {
            rec?.stop()
        } catch (_: Exception) {
        }
        try {
            rec?.release()
        } catch (_: Exception) {
        }
        try {
            echoCanceler?.release()
        } catch (_: Exception) {
        }
        echoCanceler = null
        try {
            noiseSuppressor?.release()
        } catch (_: Exception) {
        }
        noiseSuppressor = null
        val t = track
        track = null
        try {
            t?.pause()
            t?.flush()
            t?.stop()
        } catch (_: Exception) {
        }
        try {
            t?.release()
        } catch (_: Exception) {
        }
        micThread?.interrupt()
        playThread?.interrupt()
    }

    private companion object {
        const val IN_RATE = 16000
        const val OUT_RATE = 24000
        const val CHUNK_BYTES = 1280 // 40 ms of 16 kHz mono PCM16
        const val IDLE_TIMEOUT_MS = 45_000L

        /** Phrases (lower-case) with which the user ends the conversation. */
        val END_PHRASES = listOf(
            "बातचीत बंद", "बातचीत खत्म", "बात खत्म", "सुनना बंद",
            "अलविदा", "बाय ब्रह्मा", "bye brahma", "goodbye", "stop listening",
        )
    }
}

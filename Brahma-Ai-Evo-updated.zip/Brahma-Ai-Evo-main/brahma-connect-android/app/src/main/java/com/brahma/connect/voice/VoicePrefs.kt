package com.brahma.connect.voice

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Default values for the Brahma voice assistant. */
object VoiceDefaults {
    /** Primary Gemini Live (native audio) model. Editable from the Voice screen. */
    const val MODEL = "models/gemini-2.5-flash-native-audio-latest"

    /** Tried automatically, in order, if the primary model name is rejected. */
    val FALLBACK_MODELS = listOf(
        "models/gemini-2.5-flash-native-audio-preview-12-2025",
        "models/gemini-2.5-flash-native-audio-preview-09-2025",
    )

    const val VOICE = "Kore"

    /** Female-sounding Gemini prebuilt voices. All of them understand and speak Hindi (hi-IN). */
    val FEMALE_VOICES = listOf(
        "Kore",
        "Aoede",
        "Leda",
        "Zephyr",
        "Sulafat",
        "Autonoe",
        "Callirrhoe",
        "Despina",
    )

    const val WAKE_WORDS = "ब्रह्मा, हे ब्रह्मा, ओके ब्रह्मा, brahma, hey brahma"

    const val SYSTEM_PROMPT =
        "You are Brahma, a warm, friendly and smart female voice assistant. " +
            "The user mainly speaks Hindi (also Hinglish and sometimes English). " +
            "Understand Hindi very carefully, including casual and mixed Hindi-English speech. " +
            "RESPOND IN THE SAME LANGUAGE THE USER SPEAKS. If the user speaks Hindi or Hinglish, " +
            "reply in natural spoken Hindi (English technical words are fine). " +
            "Always use feminine grammar when you talk about yourself (for example: " +
            "'मैं कर रही हूँ', 'मैं बताती हूँ'). " +
            "Keep replies short and conversational, one to three sentences unless the user asks for detail. " +
            "Never read out markdown, bullet symbols or asterisks. " +
            "Stay silent until the user speaks first. " +
            "If the user interrupts you, stop and listen."
}

/** User settings for the voice feature, stored encrypted on the device. */
class VoicePrefs(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        context.applicationContext,
        "brahma_voice_secure",
        MasterKey.Builder(context.applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    var apiKey: String
        get() = prefs.getString(KEY_API, "") ?: ""
        set(value) {
            prefs.edit().putString(KEY_API, value.trim()).apply()
        }

    var model: String
        get() = (prefs.getString(KEY_MODEL, VoiceDefaults.MODEL) ?: VoiceDefaults.MODEL)
            .ifBlank { VoiceDefaults.MODEL }
        set(value) {
            prefs.edit().putString(KEY_MODEL, value.trim()).apply()
        }

    var voice: String
        get() = (prefs.getString(KEY_VOICE, VoiceDefaults.VOICE) ?: VoiceDefaults.VOICE)
            .ifBlank { VoiceDefaults.VOICE }
        set(value) {
            prefs.edit().putString(KEY_VOICE, value.trim()).apply()
        }

    var wakeWords: String
        get() = (prefs.getString(KEY_WAKE, VoiceDefaults.WAKE_WORDS) ?: VoiceDefaults.WAKE_WORDS)
            .ifBlank { VoiceDefaults.WAKE_WORDS }
        set(value) {
            prefs.edit().putString(KEY_WAKE, value.trim()).apply()
        }

    private companion object {
        const val KEY_API = "gemini_api_key"
        const val KEY_MODEL = "live_model"
        const val KEY_VOICE = "live_voice"
        const val KEY_WAKE = "wake_words"
    }
}

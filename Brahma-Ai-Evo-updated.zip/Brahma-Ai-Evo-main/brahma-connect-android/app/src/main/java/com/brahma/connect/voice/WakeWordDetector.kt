package com.brahma.connect.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Decides whether a piece of recognised speech contains the wake word. */
object WakeWordMatcher {
    /** Common ways a speech recogniser writes "Brahma" in Hindi and English. */
    private val BUILT_IN = listOf(
        "ब्रह्मा", "ब्रम्हा", "ब्रह्म", "ब्रम्ह", "ब्रहमा",
        "brahma", "bramha", "brahmaa", "brahmma",
    )

    private fun keep(ch: Char): Boolean {
        if (ch.isLetterOrDigit()) return true
        // Keep Devanagari vowel signs (matras) and virama - they are "marks", not letters.
        return when (Character.getType(ch)) {
            Character.NON_SPACING_MARK.toInt(),
            Character.COMBINING_SPACING_MARK.toInt(),
            Character.ENCLOSING_MARK.toInt() -> true
            else -> false
        }
    }

    fun normalize(text: String): String {
        val sb = StringBuilder(text.length)
        for (ch in text.lowercase()) {
            if (ch == '\u200c' || ch == '\u200d') continue
            sb.append(if (keep(ch)) ch else ' ')
        }
        return sb.toString().trim()
    }

    fun matches(text: String, extraWords: List<String>): Boolean {
        val spoken = normalize(text)
        if (spoken.isEmpty()) return false
        val candidates = (BUILT_IN + extraWords)
            .map { normalize(it) }
            .filter { it.isNotEmpty() }
            .distinct()
        return candidates.any { spoken.contains(it) }
    }
}

/**
 * Keeps Android's speech recogniser (hi-IN) running in a loop and calls [onWake]
 * as soon as the wake word is heard. All methods must be used from the main thread.
 */
class WakeWordDetector(
    private val context: Context,
    private val wakeWords: () -> List<String>,
    private val onWake: () -> Unit,
    private val onFatal: (String) -> Unit,
) {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var running = false
    private var consecutiveErrors = 0

    fun start() {
        runOnMain {
            if (running) return@runOnMain
            if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                onFatal("इस फ़ोन पर speech recognition उपलब्ध नहीं है (Google app / Speech Services चाहिए)")
                return@runOnMain
            }
            running = true
            consecutiveErrors = 0
            listen()
        }
    }

    fun stop() {
        runOnMain {
            running = false
            handler.removeCallbacksAndMessages(null)
            destroyRecognizer()
        }
    }

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else handler.post(block)
    }

    private fun listen() {
        if (!running) return
        destroyRecognizer()
        val r = try {
            SpeechRecognizer.createSpeechRecognizer(context)
        } catch (t: Throwable) {
            handleError(SpeechRecognizer.ERROR_CLIENT)
            return
        }
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                handleError(error)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                if (containsWakeWord(partialResults)) triggerWake()
            }

            override fun onResults(results: Bundle?) {
                if (containsWakeWord(results)) {
                    triggerWake()
                } else {
                    consecutiveErrors = 0
                    restart(150)
                }
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        try {
            r.startListening(intent)
        } catch (t: Throwable) {
            handleError(SpeechRecognizer.ERROR_CLIENT)
        }
    }

    private fun containsWakeWord(bundle: Bundle?): Boolean {
        val list = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return false
        val words = wakeWords()
        for (text in list) {
            if (WakeWordMatcher.matches(text, words)) return true
        }
        return false
    }

    private fun triggerWake() {
        if (!running) return
        running = false
        handler.removeCallbacksAndMessages(null)
        // Leave the recogniser callback before tearing the recogniser down.
        handler.post {
            destroyRecognizer()
            onWake()
        }
    }

    private fun handleError(error: Int) {
        if (!running) return
        when (error) {
            SpeechRecognizer.ERROR_NO_MATCH,
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                consecutiveErrors = 0
                restart(150)
            }
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                running = false
                destroyRecognizer()
                onFatal("माइक की permission नहीं मिली")
            }
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                consecutiveErrors++
                restart(1000)
            }
            else -> {
                consecutiveErrors++
                if (consecutiveErrors > 15) {
                    running = false
                    destroyRecognizer()
                    onFatal("Speech recognizer बार-बार fail हो रहा है (error $error). इंटरनेट / Google Speech Services जाँचिए")
                } else {
                    val backoff = 400L * (1L shl minOf(consecutiveErrors, 4))
                    restart(minOf(backoff, 5000L))
                }
            }
        }
    }

    private fun restart(delayMs: Long) {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ if (running) listen() }, delayMs)
    }

    private fun destroyRecognizer() {
        val r = recognizer ?: return
        recognizer = null
        try {
            r.cancel()
        } catch (_: Exception) {
        }
        try {
            r.destroy()
        } catch (_: Exception) {
        }
    }
}

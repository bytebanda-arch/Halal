package com.brahma.connect.voice

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class VoiceMode { OFF, WAKE_LISTENING, CONNECTING, LIVE }

data class VoiceLine(val id: Long, val role: String, val text: String)

/** Shared, observable state of the voice assistant (service writes, UI reads). */
object VoiceStateStore {
    private val _mode = MutableStateFlow(VoiceMode.OFF)
    val mode: StateFlow<VoiceMode> = _mode.asStateFlow()

    private val _wakeActive = MutableStateFlow(false)
    val wakeActive: StateFlow<Boolean> = _wakeActive.asStateFlow()

    private val _status = MutableStateFlow("बंद है")
    val status: StateFlow<String> = _status.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _lines = MutableStateFlow<List<VoiceLine>>(emptyList())
    val lines: StateFlow<List<VoiceLine>> = _lines.asStateFlow()

    private val lock = Any()
    private var nextId = 1L
    private var openRole: String? = null

    fun setMode(mode: VoiceMode, status: String) {
        _mode.value = mode
        _status.value = status
    }

    fun setStatus(text: String) {
        _status.value = text
    }

    fun setWakeActive(active: Boolean) {
        _wakeActive.value = active
    }

    fun setError(text: String?) {
        _error.value = text
    }

    /** Adds a streaming transcript fragment to the current line of [role] ("user" or "model"). */
    fun appendTranscript(role: String, chunk: String) {
        if (chunk.isEmpty()) return
        synchronized(lock) {
            val current = _lines.value
            if (openRole == role && current.isNotEmpty() && current.last().role == role) {
                val last = current.last()
                _lines.value = current.dropLast(1) + last.copy(text = last.text + chunk)
            } else {
                openRole = role
                _lines.value = (current + VoiceLine(nextId++, role, chunk.trimStart())).takeLast(60)
            }
        }
    }

    fun closeTurn() {
        synchronized(lock) { openRole = null }
    }

    fun clearTranscript() {
        synchronized(lock) {
            openRole = null
            _lines.value = emptyList()
        }
    }
}

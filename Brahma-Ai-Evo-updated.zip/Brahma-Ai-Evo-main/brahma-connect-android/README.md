# Brahma Connect Android

Android agent for Brahma Connect.

What this project is:
- Native Android agent
- WebSocket client for the existing Brahma Gateway
- Minimal pairing and reconnect flow
- First command set only

What this project is not:
- Not an AI assistant
- Not a second dashboard
- Not a cloud service
- Not a Windows or Companion build

Build requirements:
- Android Studio or Android Gradle Plugin toolchain
- JDK 17
- Android SDK 35

Phase scope:
- Gateway discovery
- QR pairing
- Secure credential storage
- Persistent WebSocket connection
- Battery, flashlight, launch app, open URL, and volume commands

## Brahma Voice (wake word + Hindi live talk)

New in this version (`app/src/main/java/com/brahma/connect/voice/`):

- **Wake word** - say "ब्रह्मा" / "हे ब्रह्मा" / "hey brahma" and the live conversation starts
  (hi-IN speech recogniser, runs in a foreground microphone service).
- **Live Talk** - real-time two-way voice with Gemini Live (native audio). Understands Hindi / Hinglish / English,
  you can interrupt it while it is speaking, and it uses echo cancellation.
- **Female voices** - Kore (default), Aoede, Leda, Zephyr, Sulafat, Autonoe, Callirrhoe, Despina. Pick one on the Voice screen.
- Say "बातचीत बंद" / "अलविदा" to end a conversation. It also closes itself after 45 s of silence.

Open the app -> **Brahma Voice** -> paste your Gemini API key -> **Save** -> press **Live Talk** or switch on **Wake word**.
The API key is stored encrypted on the phone and is only sent to Google.

## Build the APK on GitHub (no Android Studio needed)

1. Push this whole repository to GitHub.
2. Open the repo -> **Actions** -> **Build Android APK** -> **Run workflow**.
3. When it finishes (about 5-8 minutes) open the run and download **BrahmaConnect-debug-apk** from *Artifacts*.
   Unzip it and install `BrahmaConnect-debug.apk` on the phone (allow "install unknown apps").
4. Optional: push a tag such as `android-v1.0.0` and the APK is also attached to a GitHub Release.
